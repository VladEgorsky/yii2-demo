<?php

namespace common\modules\seo;


class Module extends \yii\base\Module
{
    public $controllerNamespace = 'common\modules\seo\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}